package vo;

public class FriendVO {
	
	private int idx;
	private String i;
	private String friend;
	private String will;
	
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public String getI() {
		return i;
	}
	public void setI(String i) {
		this.i = i;
	}
	public String getFriend() {
		return friend;
	}
	public void setFriend(String friend) {
		this.friend = friend;
	}
	public String getWill() {
		return will;
	}
	public void setWill(String will) {
		this.will = will;
	}
	
	

}
